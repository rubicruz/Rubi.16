﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2_RPCS_1347424
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese la hora (de 0 a 23): ");
            int hora;
            hora = Convert.ToInt16(Console.ReadLine());
            if (hora > 6 && hora < 12)
                Console.WriteLine("BUENOS DÍAS!");
            else if (hora >= 12 && hora < 18)
                Console.WriteLine("BUENAS TARDES!");
            else
                Console.WriteLine("BUENAS NOCHES!"); 



            //EJERCICIO 2
            string sonido;
            Console.Write("Ingrese sonido: ");
            sonido = Console.ReadLine();
            switch (sonido)
            {
                case "muu":
                    Console.WriteLine("Es una vaca. ");
                    break;
                case "guau":
                    Console.WriteLine("Es un perro. ");
                    break;
                case "cuac":
                    Console.WriteLine("Es un pato. ");
                    break;
                default:
                    Console.WriteLine("Sonido desconocido. ");
                    break;
            }
            //EJERCICIO 3
            string caracter;
            int largo;
            Console.Write("Ingrese el caracter que desea imrpimir: ");
            caracter = Console.ReadLine();
            Console.Write("Ingrese el largo del lado del cuadrado: ");
            largo = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine("");

            for (int i = 1; i < largo; i++)
            {
                for (int j = 1; j <= largo; j++)
                {
                    Console.Write(caracter);
                }
                Console.WriteLine("");
            }

            //EJERCICIO 4
            string opcion;
            opcion = "_";
            while (opcion != "d")
            {
                Console.Clear();
                Console.WriteLine("         MENU");
                Console.WriteLine("");
                Console.WriteLine("a. Opción 1");
                Console.WriteLine("b. Opción 2");
                Console.WriteLine("c. Opcion 3");
                Console.WriteLine("d. Salir");
                Console.Write("Ingrese una opción: ");
                opcion = Console.ReadLine();

                if (opcion == "a")
                {
                    Console.WriteLine("Seleccione la opción 1.");
                }
                else if (opcion == "b")
                {
                    Console.WriteLine("Seleccione la opción 2.");
                }
                else if (opcion == "c")
                {
                    Console.WriteLine("Seleccione la opción 3.");
                }
                else if (opcion == "d")
                {

                }
                else
                {
                    Console.WriteLine("Opción invalida");
                }

                Console.WriteLine("");
                Console.WriteLine("presione la tecla espacio para continuar...");
                Console.ReadKey();
            }
            Console.WriteLine("");
            Console.WriteLine("Gracias por usar nuestro sistema");
            Console.ReadKey();
        }
    }
}
