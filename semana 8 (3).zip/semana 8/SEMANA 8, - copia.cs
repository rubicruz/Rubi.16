﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese su nombre");
            String nombre;
            nombre = Console.ReadLine();
            Console.WriteLine("Hola " + nombre + " Bienvenido");
            Console.Write("Un mensaje cualquiera");
            Console.WriteLine("");
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Ingrese su nombre");
            String nombre1;
            nombre1 = Console.ReadLine();
            Console.WriteLine("Ingrese su edad");
            int edad;
            edad = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese su carrera");
            string carrera;
            carrera = Console.ReadLine();
            Console.WriteLine("Ingrese su carne");
            int carne;
            carne = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Soy " + nombre1 + " tengo " + edad + " años y estudio la carrera de " + carrera + " y el carne es " + carne);
            Console.WriteLine("Ejercicio 3");
            Console.Write("Ingresa la temperatura en grados Celsius: "); double celsius = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(celsius * 9 / 5 + 32);
            Console.WriteLine("La temperatura en grados Fahrenheit es: " + 9/5 + 32);
            Console.WriteLine("Ejercicio 4");
            Console.Write("Ingrese el primer número");












        }
    }
}
